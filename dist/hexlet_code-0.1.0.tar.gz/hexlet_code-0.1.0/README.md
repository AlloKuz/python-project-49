### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlloKuz/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlloKuz/python-project-49/actions)

<a href="https://codeclimate.com/github/AlloKuz/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d8fc2c7390e46fd8c6dc/maintainability" /></a>

<a href="https://asciinema.org/a/tJjL1jlFmQsMvggNlQiwuLR45" target="_blank"><img src="https://asciinema.org/a/tJjL1jlFmQsMvggNlQiwuLR45.svg" /></a>
