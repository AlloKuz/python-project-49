### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlloKuz/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlloKuz/python-project-49/actions)

<a href="https://codeclimate.com/github/AlloKuz/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d8fc2c7390e46fd8c6dc/maintainability" /></a>

Игра: «Проверка на чётность»

Суть игры в следующем: пользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное.

<a href="https://asciinema.org/a/tJjL1jlFmQsMvggNlQiwuLR45" target="_blank"><img src="https://asciinema.org/a/tJjL1jlFmQsMvggNlQiwuLR45.svg" /></a>

Игра: «Калькулятор»

Суть игры в следующем: пользователю показывается случайное математическое выражение, например, 35 + 16, которое нужно вычислить и записать правильный ответ.

<a href="https://asciinema.org/a/reJrEtdI5My0NczHISKWWIqzy" target="_blank"><img src="https://asciinema.org/a/reJrEtdI5My0NczHISKWWIqzy.svg" /></a>

Игра «НОД»

Суть игры в следующем: пользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.

