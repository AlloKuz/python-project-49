from brain_games.games import progression


def main():
    progression.run_game()


if __name__ == "__name__":
    main()
