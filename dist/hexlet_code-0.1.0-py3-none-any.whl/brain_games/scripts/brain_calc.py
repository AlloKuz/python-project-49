from brain_games.games import calc


def main():
    calc.run_game()


if __name__ == "__name__":
   main()
