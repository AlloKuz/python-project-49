from brain_games.games import prime


def main():
    prime.run_game()


if __name__ == "__name__":
    main()
