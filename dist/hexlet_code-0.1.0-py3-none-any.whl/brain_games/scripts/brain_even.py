from brain_games.games import even


def main():
    even.run_game()


if __name__ == "__name__":
    main()
